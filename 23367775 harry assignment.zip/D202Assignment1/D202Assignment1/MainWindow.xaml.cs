﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace D202Assignment1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public HashTable management;
        public WaitingList waitingList;
        public string[] peekQueue;
        public Movie[] movies;

        public MainWindow()
        {
            InitializeComponent();

            ///////////////////////////////////////////////////////////////////////  HASH TABLE TEST

            //construct new hash table
            management = new HashTable();

            //construct new sample data
            Movie m1 = new Movie("I1", "Inception", "Christopher Nolan", "Action/Thriller", 2010, true);
            Movie m2 = new Movie("T1", "The Shawshank Redemption", "Frank Darabont", "Drama", 1994, true);
            Movie m3 = new Movie("T2", "Tenet", "Christopher Nolan", "Action/Sci-Fi", 2020, true);
            Movie m4 = new Movie("C1", "Cars", "John Lasseter", "Family/Animation", 2006, true);
            Movie m5 = new Movie("D1", "Django Unchained", "Quentin Tarantino", "Western", 2012, true);
            Movie m6 = new Movie("C2", "Cars 2", "John Lasseter", "Family/Animation", 2011, true);

            //inserting data into movies array for future use
            movies = new Movie[] { m1, m2, m3, m4, m5, m6 };

            //inserting data into hash table
            management.Insert(m1.MovieID, m1);
            management.Insert(m2.MovieID, m2);
            management.Insert(m3.MovieID, m3);
            management.Insert(m4.MovieID, m4);
            management.Insert(m5.MovieID, m5);
            management.Insert(m6.MovieID, m6);

            //get value with key
            Movie requested = management.GetValue("T1");
            //if value is found
            if (requested != null)
            {
                //print movie title to label
                lblTestHash.Content = $"{requested.Title.ToString()} ({requested.ReleaseYear.ToString()})";
            }
            //if not found
            else
            {
                //print error
                lblTestHash.Content = "Movie does not exist.";
            }



            //waiting list
            waitingList = new WaitingList(10);

            

        }

        public class Movie
        {
            //defining movie properties
            public string MovieID { get; set; }
            public string Title { get; set; }
            public string Director { get; set; }
            public string Genre { get; set; }
            public int ReleaseYear { get; set; }
            public bool Availability { get; set; }
            public string Borrower { get; set; }

            //initialise properties using constructor
            public Movie(string movieid, string title, string director, string genre, int releaseyear, bool availability)
            {
                MovieID = movieid;
                Title = title;
                Director = director;
                Genre = genre;
                ReleaseYear = releaseyear;
                Availability = availability;
            }

        }

        //make hash table
        public class HashTable
        {
            public string[] keys;
            public Movie[] values;
            public int capacity;
            private int size;

            //initialise hash table with initial capacity (later resizable?)
            public HashTable(int initial = 10)
            {
                capacity = initial;
                keys = new string[capacity];
                values = new Movie[capacity];
                size = 0;
            }

            //method to generate hash
            public int GetHash(string key)
            {
                //set default hash to 0
                int hash = 0;

                //foreach loop grabs ASCII value for each character in key
                foreach (char c in key)
                {
                    //add ASCII int value to hash
                    hash += c;
                }
                //return hash with modulus operator % to keep in array
                return hash % capacity;

            }

            //method to get key and search
            public Movie GetValue(string key)
            {
                //get hash for starting index
                int index = GetHash(key);

                //while slot isnt empty
                while (keys[index] != null)
                {
                    //if keys match return movie
                    if (keys[index] == key)
                    {
                        return values[index];
                    }
                    //if no match, move forward and keep in bounds of array
                    index = (index + 1) % capacity;
                }

                //if key not found return null
                return null;
            }

            //method to insert hash value
            public void Insert(string key, Movie value)
            {
                //get hash for starting index
                int index = GetHash(key);

                //while slot isnt empty and while it doesnt match
                while (keys[index] != null && keys[index] != key)
                {
                    //move forward and keep in bounds of array
                    index = (index + 1) % capacity;
                }

                //if empty slot, increase size
                if (keys[index] == null)
                {
                    size++;
                }

                //insert key and value at index
                keys[index] = key;
                values[index] = value;

            }

            //method to check if key exists
            public bool ExistingKey(string key)
            {
                //return bool on key check
                return keys.Contains(key);
            }

        }

        //make node with data and next address for linked list
        public class Node
        {
            public Movie Data;
            public Node Next;

            //initialise with next default null
            public Node(Movie data)
            {
                Data = data;
                Next = null;
            }
        }

        //make linked list
        public class LinkedList
        {
            //create head node
            public Node head;

            //method for adding node with data
            public void AddNode(Movie data)
            {
                //make node
                Node node = new Node(data);

                //if head is null (aka empty list), set node as head
                if (head == null)
                {
                    head = node;
                }
                //if head isnt null
                else
                {
                    //set head as current node
                    Node currentNode = head;

                    //while current isnt tail end of list (current.Next != null)
                    while (currentNode.Next != null)
                    {
                        //move forward next position in list
                        currentNode = currentNode.Next;
                    }
                    //put new node at end and set as currentNode next address
                    currentNode.Next = node;
                }

            }
        }

        //make queue for waiting list
        public class WaitingList
        {
            //array of usernames for queue
            public string[] elements;
            private int size;

            //initialise list with maximum
            public WaitingList(int maximum)
            {
                elements = new string[maximum];
                size = 0;
            }

            //method to add item to end of queue
            public void Enqueue(string username)
            {
                //if queue is full, throw error
                if (size == elements.Length)
                {
                    throw new InvalidOperationException("Waiting List at maximum.");
                }

                //add item at end, then increase size
                elements[size] = username;
                size++;

            }

            //method to remove first item in queue (when item is coming off waiting list)
            public string Dequeue()
            {
                //if queue is empty, throw error
                if (size == 0)
                {
                    throw new InvalidOperationException("Waiting List is empty.");
                }

                //get first item in queue
                string user = elements[0];

                //remove first item and shift everything back 1 position
                for (int i = 1; i < size; i++)
                {
                    elements[i - 1] = elements[i];
                }

                //reduce size of queue
                size--;

                //return user
                return user;

            }

            //method to view waiting list queue
            public string[] Peek()
            {
                //if queue is empty, throw error
                if (size == 0)
                {
                    throw new InvalidOperationException("Waiting List is empty.");
                }

                //get copy of part of array in use
                string[] inUse = new string[size];
                Array.Copy(elements, inUse, size);

                //return copied queue
                return inUse;

            }

            //method to view single item in queue
            public string Peek(int index)
            {
                //if queue is empty, throw error
                if (size == 0)
                {
                    throw new InvalidOperationException("Waiting List is empty.");
                }
                //if index is out of range of queue
                if (index < 0 || index >= elements.Length)
                {
                    throw new IndexOutOfRangeException("Index is out of bounds of array.");
                }
                
                //return singular movie
                return elements[index];

            }

        }

        //method to linear search by title
        public static Movie LinearSearch(Movie[] arr, string title)
        {
            //for loop to search through array
            for (int i = 0; i < arr.Length; i++)
            {
                //if array item title is same as title, return it
                if (arr[i].Title == title)
                {
                    return arr[i];
                }
            }
            //if not found, return null
            return null;
        }

        //method to binary search by movie id using comparer
        public static Movie BinarySearch(Movie[] arr, string movieID, IDComparer comparer)
        {
            //
            BubbleSort(arr, "id");

            //
            int left = 0;
            int right = arr.Length - 1;

            //
            while (left <= right)
            {
                //
                int mid = left + (right - left) / 2;

                //
                int comp = comparer.Compare(arr[mid].MovieID, movieID);

                //
                if (comp == 0)
                {
                    return arr[mid];
                }
                //
                else if (comp < 0)
                {
                    left = mid + 1;
                }
                else
                {
                    right = mid - 1;
                }

            }
            return null;

        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            //grab input from tbx
            string content = tbxSearchBox.Text;

            //initialise linear search with input
            Movie retrieved = LinearSearch(movies, content);

            //convert retrieved to array
            Movie[] data = new Movie[] { retrieved };

            //
            if (retrieved != null)
            {
                lsvAnswerBox.ItemsSource = data;
            }
            else
            {
                //
                IDComparer comparer = new IDComparer();

                //
                retrieved = BinarySearch(movies, content, comparer);

                //
                data = new Movie[] { retrieved };

                //
                lsvAnswerBox.ItemsSource = data;
            }

        }

        //build comparer so code understands how to sort ids
        public class IDComparer
        {
            //method to compare 2 ids
            public int Compare(string idX, string idY)
            {
                //get first character of each id and set to variable
                char preX = idX[0];
                char preY = idY[0];

                //take everything after first character (number) and parse to variable
                int sufX = int.Parse(idX.Substring(1));
                int sufY = int.Parse(idY.Substring(1));

                //compare first chars for alphabetical order
                int firstCompare = preX.CompareTo(preY);

                //if value is 0 (same prefix), compare other chars for numerical order
                if (firstCompare == 0)
                {
                    int secondCompare = sufX.CompareTo(sufY);
                    //return numerical comparison as int
                    return secondCompare;
                }
                else
                {
                    //return alphabetical comparison as int
                    return firstCompare;
                }

            }
        }

        //method to execute bubble sort by id or title
        public static void BubbleSort(Movie[] arr, string sortBy)
        {
            //initialise comparer
            IDComparer comparer = new IDComparer();

            //
            for (int i = 0; i < arr.Length - 1; i++)
            {
                //
                for (int j = 0; j < arr.Length - 1 - i; j++)
                {
                    //check if requested bubble sort is by id
                    if (sortBy == "id")
                    {
                        //
                        if (comparer.Compare(arr[j].MovieID, arr[j + 1].MovieID) > 0)
                        {
                            //
                            Movie holder = arr[j];
                            arr[j] = arr[j + 1];
                            arr[j + 1] = holder;
                        }
                    }
                    //check if requested bubble sort is by title
                    else if (sortBy == "title")
                    {
                        //
                        if (string.Compare(arr[j].Title, arr[j + 1].Title, StringComparison.OrdinalIgnoreCase) > 0)
                        {
                            //
                            Movie holder = arr[j];
                            arr[j] = arr[j + 1];
                            arr[j + 1] = holder;
                        }
                    }

                }
            }

        }

        //method to execute merge sort by release year
        public static void MergeSort(Movie[] arr, int left, int right)
        {
            //
            if (left < right)
            {
                //
                int mid = (left + right) / 2;

                //
                MergeSort(arr, left, mid);
                MergeSort(arr, mid + 1, mid);

                //
                Merge(arr, left, mid, right);
            }
        }

        //method to merge array together for merge sort
        private static void Merge(Movie[] arr, int left, int mid, int right)
        {
            //
            Movie[] placeholderArray = new Movie[right - left + 1];

            //variable for start of each half
            int x = left;
            int y = mid + 1;

            //placeholder array index
            int index = 0;

            //
            while (mid >= x && right >= y)
            {
                //if right value is greater than left value
                if (arr[x].ReleaseYear <= arr[y].ReleaseYear)
                {
                    //
                    placeholderArray[index++] = arr[x++];
                }
                else
                {
                    //
                    placeholderArray[index++] = arr[y++];
                }
            }

            //grab remaining elements in left half
            while (x <= mid)
            {
                placeholderArray[index++] = arr[x++];
            }
            //grab remaining elements in right half
            while (y <= right)
            {
                placeholderArray[index++] = arr[y++];
            }

            //put placeholder array values into original array
            for (index = 0; index < placeholderArray.Length; index++)
            {
                arr[left + index] = placeholderArray[index];
            }

        }

        private void btnTitleSort_Click(object sender, RoutedEventArgs e)
        {
            //
            lsvAnswerBox.ItemsSource = null;

            //
            BubbleSort(movies, "title");

            //
            lsvAnswerBox.ItemsSource = movies;

        }

        private void btnYearSort_Click(object sender, RoutedEventArgs e)
        {
            //
            lsvAnswerBox.ItemsSource = null;

            //
            MergeSort(movies, 0, movies.Length - 1);

            //
            lsvAnswerBox.ItemsSource = movies;
        }

        //method to borrow movie
        public void BorrowMovie(string MovieID, string username)
        {
            //get movie from hash table
            Movie movie = management.GetValue(MovieID);

            //if no movie exists
            if (movie == null)
            {
                //error box and break
                MessageBox.Show("No existing movie.");
                return;
            }

            //if movie is available
            if (movie.Availability == true)
            {
                //make not available and confirm borrow
                movie.Availability = false;
                MessageBox.Show($"{username} is now borrowing {movie.Title} ({movie.ReleaseYear})");
                movie.Borrower = username;
            }
            else
            {
                //movie not available, add person to queue
                waitingList.Enqueue(username);
                MessageBox.Show($"{movie.Title} ({movie.ReleaseYear}) isn't available. {username} is now in waiting list.");
            }

        }

        //method to return movie
        public void ReturnMovie (string MovieID, string username)
        {
            //get movie from hash table
            Movie movie = management.GetValue(MovieID);

            //if no movie exists
            if (movie == null)
            {
                //error box and break
                MessageBox.Show("No existing movie.");
                return;
            }

            //if movie borrower is returner
            if (username == movie.Borrower)
            {
                //if movie is borrowed
                if (movie.Availability != true)
                {
                    //make available
                    movie.Availability = true;

                    try
                    {
                        //take top from waiting queue and make them next borrower
                        string newBorrower = waitingList.Dequeue();
                        movie.Availability = false;
                        MessageBox.Show($"{movie.Title} ({movie.ReleaseYear}) has been borrowed by {newBorrower}.");
                        movie.Borrower = newBorrower;
                    }
                    catch (InvalidOperationException)
                    {
                        //no waiting list, confirm available
                        MessageBox.Show($"{movie.Title} ({movie.ReleaseYear}) is now available.");
                        movie.Borrower = null;
                    }
                }
                else
                {
                    //else movie is not borrowed and already returned
                    MessageBox.Show("This movie has already been returned.");
                }
            }
            else
            {
                //movie borrower is different, cant return
                MessageBox.Show("You cannot return this item.");
            }
        }

        private void btnBorrow_Click(object sender, RoutedEventArgs e)
        {
            //grab selected movie
            Movie selected = lsvAnswerBox.SelectedItem as Movie;

            //grab username and id from selected, then execute borrow method
            BorrowMovie(selected.MovieID, tbxUserInput.Text);
        }

        private void btnReturn_Click(object sender, RoutedEventArgs e)
        {
            //grab selected movie
            Movie selected = lsvAnswerBox.SelectedItem as Movie;

            //grab username and id from selected, then execute borrow method
            ReturnMovie(selected.MovieID, tbxUserInput.Text);
        }
    }
}